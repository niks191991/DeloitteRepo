/**
 * 
 */
package org.deloitte.digital.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

/**
 * @author Nikhil Tyagi
 * This class is Utility class contains all the utility methods of Application.
 * loadProperties
 * shufflescheduleByTimeSlot
 * initalizeStack
 * getTimeByscheduleList
 * shuffleAndSortschedule
 * sumOfSlots
 * 
 *
 */
public class ScheduleUtility implements ScheduleConstants{

	static Map<String,String> properties = new HashMap<>();
	
	/**
	 * 
	 * @return Map<String,String> : properties
	 * This method load the property from the property file and prepare the KEY:VALUE Data
	 */
	public static Map<String,String> loadProperties(){
		Properties prop = new Properties();
		try {
			if(properties.size() == 0){
			/*	ClassLoader classLoader = new scheduleUtility().getClass().getClassLoader();
				File file = new File(classLoader.getResource(CONFIGURATIONFILE_NAME).getFile());*/
				
				try(InputStream input =ScheduleUtility.class.getClassLoader().getResourceAsStream(CONFIGURATIONFILE_NAME)){
					prop.load(input);
					properties.put(FILE_BASE_PATH, prop.getProperty(FILE_BASE_PATH));
					properties.put(INPUT_FILE_NAME, prop.getProperty(INPUT_FILE_NAME));
					properties.put(OUTPUT_FILE_PATH, prop.getProperty(OUTPUT_FILE_PATH));
					properties.put(OUTPUT_FILE_NAME, prop.getProperty(OUTPUT_FILE_NAME));
					properties.put(OUTPUT_FILE_NAME, prop.getProperty(OUTPUT_FILE_NAME));
					properties.put(SPRINT_TIME, prop.getProperty(SPRINT_TIME));
					properties.put(FIRST_TEAM_NAME, prop.getProperty(FIRST_TEAM_NAME));
					properties.put(SECOND_TEAM_NAME, prop.getProperty(SECOND_TEAM_NAME));
					properties.put(STAFF_schedule_NAME, prop.getProperty(STAFF_schedule_NAME));
				}
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return properties;
	}

	/**
	 * @author Nikhil Tyagi
	 * @param schedule
	 * @return shuffle
	 * This method shuffle the timings and sort it in DESC order and prepare the LIST
	 */
	public static List<String> shufflescheduleByTimeSlot(List<String> schedule) {
		List<String> shuffle = new ArrayList<>();
		for (String timing : schedule) {
			String lastWord = timing.substring(timing.lastIndexOf(' ') + 1);
			timing = timing.replaceAll(lastWord, "").trim();
			timing = lastWord + " " + timing;
			timing = timing.replaceAll(SPRINT, properties.get(SPRINT_TIME)).trim();
			shuffle.add(timing);
		}
		return shuffle;

	}
	/**
	 * @author Nikhil Tyagi
	 * @param listOfSlots
	 * Initialize the slots of list objects 
	 */
	public static void initalizeStack(List<List<Integer>> listOfSlots) {
		List<Integer> Q912Q1 = new ArrayList<>();
		List<Integer> Q912Q2 = new ArrayList<>();
		List<Integer> Q15Q1 = new ArrayList<>();
		List<Integer> Q15Q2 = new ArrayList<>();
		listOfSlots.add(Q15Q1);
		listOfSlots.add(Q15Q2);
		listOfSlots.add(Q912Q1);
		listOfSlots.add(Q912Q2);
	}
	/**
	 * @author Nikhil Tyagi
	 * @param scheduleWithTime
	 * @return Integer
	 * Returns the timings from the schedule Name
	 */
	public static Integer getTimeByscheduleList(String scheduleWithTime) {
		StringTokenizer token = new StringTokenizer(scheduleWithTime, MINUTES);
		return Integer.valueOf(token.nextToken());
	}
	/**
	 * @author Nikhil Tyagi
	 * @param schedule
	 * @return scheduleNameShuffle
	 * This method shuffle the timings and sort it in DESC order and prepare the LIST
	 */
	public static List<String>  shuffleAndSortschedule(List<String> schedule){
		List<String> scheduleNameShuffle = new ArrayList<>();
		scheduleNameShuffle = ScheduleUtility.shufflescheduleByTimeSlot(schedule);
		scheduleNameShuffle.sort((e1, e2) -> e2.compareTo(e1));

		return scheduleNameShuffle;
	}
	/**
	 * @author Nikhil Tyagi
	 * @param listValuesOfSlot
	 * @return sum
	 * This method returns the sum of all the timings from the specific slot to evaluate the best Slot for the presentation.
	 */
	public static Integer sumOfSlots(List<Integer> listValuesOfSlot){
		Integer sum = listValuesOfSlot.stream().collect(Collectors.summingInt(Integer::intValue));
		return sum;
	}

}
