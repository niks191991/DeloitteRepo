/**
 * 
 */
package org.deloitte.digital.utilities;

/**
 * @author Nikhil Tyagi
 * This class contains constant used in the application
 *
 */
public interface ScheduleConstants {
	
	String FILE_BASE_PATH="file.input.path";
	String INPUT_FILE_NAME="file.input.fileName";
	String OUTPUT_FILE_PATH="file.output.path";
	String OUTPUT_FILE_NAME="file.out.fileName";
	
	String SPRINT_TIME="time.sprint";
	String FIRST_TEAM_NAME="team.name.first";
	String SECOND_TEAM_NAME="team.name.second";
	String STAFF_schedule_NAME="Staff.presentation.name";
	
	String CONFIGURATIONFILE_PATH="DeloitteDigitalAwayDay/";
	String CONFIGURATIONFILE_NAME="configuration.properties";
	String INPUT_FILE="schedule.txt";
	int TOTALMORNING = 180;
	int TOTALEVENING = 240;
	int SIXTY_MINUTES=60;
	String MINUTES="min";
	
	String EXCEPTION_FILE_EXPORT="Error while Exporting the File";
	
	String NEXT_LINE="\n";
	String START_TIME="09:00";
	String LUNCH_TIME="12:00";
	String TIMINGS_FORMAT="hh:mm a";
	String SPRINT="sprint";
	String LUNCH_BREAK="Lunch Break 60min";
	String COLON=" : ";
	

}
