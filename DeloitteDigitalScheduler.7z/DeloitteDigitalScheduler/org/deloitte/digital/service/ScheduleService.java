/**
 * 
 */
package org.deloitte.digital.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

/**
 * @author Nikhil Tyagi
 * Interface used in the service layer flow.
 */
public interface ScheduleService {
	
	public  Integer bestSlotByTime(Integer presentationMinutes, List<List<Integer>> stack) throws Exception;
	public StringBuilder arrangescheduleBySlot(List<String> activities, List<List<Integer>> slotArrangement) throws Exception;
	public List<String> readInputFile() throws FileNotFoundException,IOException,URISyntaxException;
	public boolean writeFile(String data) throws IOException;

}
