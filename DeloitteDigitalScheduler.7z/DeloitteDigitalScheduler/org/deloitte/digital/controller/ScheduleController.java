/**
 * This file handles the controller layer flow of Deloitte Digital Away Day
 *  
 */
package org.deloitte.digital.controller;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.deloitte.digital.service.ScheduleService;
import org.deloitte.digital.serviceImpl.ScheduleServiceImpl;
import org.deloitte.digital.utilities.ScheduleUtility;

/**
 * @author Nikhil Tyagi
 * This controller contains entry method which internally calls service layer methods to
 * evaluate the schedule time slots
 */
public class ScheduleController {

	//Service Injection from Controller
	static ScheduleService serviceInjection = new ScheduleServiceImpl();
	private static List<List<Integer>> listOfSlots = new ArrayList<>(); 

	/**
	 * @param args
	 * This main(args) method is the entry point the application.
	 */
	public static void main(String[] args) throws Exception{

		List<String> schedule = null;
		List<String> scheduleNameShuffle = null;
		try {
			//Initialize the Slots
			ScheduleUtility.initalizeStack(listOfSlots);
			//read the file from the  path and load the data in the list
			schedule = serviceInjection.readInputFile();
			/*
			 * Shuffle and sort the timings based on the DESC order of the Presentation timings
			 * Example: 60 minutes presentation at the top & sprint in the end to evaluate 
			 * 			the schedule using Greedy Selection Algorithm
			 */
			
			scheduleNameShuffle = ScheduleUtility.shuffleAndSortschedule(schedule);
			// Iterate the schedule and based on the time find the best slot for it.
			for (String time : scheduleNameShuffle) {
				Integer timinigs = ScheduleUtility.getTimeByscheduleList(time);
				// calling the method to find the best Slot  for the presentation.
				int slotIndex = serviceInjection.bestSlotByTime(timinigs, listOfSlots);
				// Add the presentation in the best slot.
				listOfSlots.get(slotIndex).add(timinigs);
			}
			// arranging the activities and prepare the output file data
			StringBuilder str = serviceInjection.arrangescheduleBySlot(schedule, listOfSlots); 
			// Write file to the path configured in configuration.properties
			boolean result = serviceInjection.writeFile(str.toString());
			
			if(result){
				System.out.println("Schedule prepared. Navigate to C:\\Scheduler_Deloitte");
			}else{
				System.out.println("Scheduler failed"); 
			}

		} catch (FileNotFoundException e3) {
			throw new Exception(e3.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

	}
}
